(() => {
  class AutomationEngine {
    constructor(adapter, report) {
      this.adapter = adapter;
      this.report = report;
      this.state = {
        status: "STOPPED", messagesSent: 0, nextAt: null,
        error: "", tabUrl: location.href, config: null
      };
      this.timer = null;
      this.deadline = null;
      this.remainingMs = 0;
      this.runId = 0;
      this.busy = false;
    }

    snapshot() { return structuredClone(this.state); }
    update(patch) {
      this.state = { ...this.state, ...patch };
      this.report(this.snapshot());
    }

    async start(config) {
      this.clearTimer();
      this.runId += 1;
      this.busy = false;
      this.remainingMs = 0;
      this.state.config = {
        message: String(config.message || ""),
        intervalSeconds: Math.max(1, Math.min(86400, Number(config.intervalSeconds) || 30)),
        sendImmediately: Boolean(config.sendImmediately),
        waitForResponse: Boolean(config.waitForResponse),
        selectedAI: config.selectedAI || this.adapter.id
      };
      this.update({ status: "RUNNING", messagesSent: 0, nextAt: null, error: "" });
      const id = this.runId;
      if (this.state.config.sendImmediately) this.cycle(id);
      else this.schedule(this.state.config.intervalSeconds * 1000, id);
      return this.snapshot();
    }

    pause() {
      if (this.state.status !== "RUNNING" && this.state.status !== "WAITING_FOR_RESPONSE") return this.snapshot();
      if (this.timer) {
        this.remainingMs = Math.max(0, this.deadline - Date.now());
        this.clearTimer();
      }
      this.update({ status: "PAUSED", nextAt: null });
      return this.snapshot();
    }

    resume() {
      if (this.state.status !== "PAUSED") return this.snapshot();
      this.update({ status: "RUNNING", error: "" });
      const delay = this.remainingMs || this.state.config.intervalSeconds * 1000;
      this.remainingMs = 0;
      this.schedule(delay, this.runId);
      return this.snapshot();
    }

    stop(message = "") {
      this.runId += 1;
      this.clearTimer();
      this.busy = false;
      this.remainingMs = 0;
      this.update({ status: "STOPPED", nextAt: null, error: message });
      return this.snapshot();
    }

    clearTimer() {
      if (this.timer) clearTimeout(this.timer);
      this.timer = null;
      this.deadline = null;
    }

    schedule(delay, id) {
      if (id !== this.runId || this.state.status !== "RUNNING") return;
      this.clearTimer();
      const safeDelay = Math.max(0, delay);
      this.deadline = Date.now() + safeDelay;
      this.update({ nextAt: this.deadline });
      this.timer = setTimeout(() => {
        this.timer = null;
        this.deadline = null;
        this.cycle(id);
      }, safeDelay);
    }

    async cycle(id) {
      if (id !== this.runId || this.state.status !== "RUNNING" || this.busy) return;
      this.busy = true;
      this.update({ nextAt: null, error: "" });
      try {
        if (location.hostname !== new URL(this.state.tabUrl).hostname) {
          this.stop("AI website changed. Automation stopped.");
          return;
        }
        const composer = this.adapter.findComposer();
        if (!composer) throw new Error("Could not find the message box. Make sure an AI conversation is open.");
        await this.adapter.insertMessage(this.state.config.message);
        if (id !== this.runId || this.state.status !== "RUNNING") return;
        const submitted = await this.adapter.sendMessage(() => id === this.runId && this.state.status === "RUNNING");
        if (id !== this.runId || this.state.status === "STOPPED" || !submitted) return;
        this.update({ messagesSent: this.state.messagesSent + 1 });
        if (this.state.status === "PAUSED") return;
        if (this.state.config.waitForResponse) {
          this.update({ status: "WAITING_FOR_RESPONSE" });
          await this.adapter.waitForResponseToFinish({
            isCurrent: () => id === this.runId && this.state.status !== "STOPPED",
            onWaiting: () => this.update({ status: "WAITING_FOR_RESPONSE" })
          });
        }
        if (id !== this.runId || this.state.status === "STOPPED") return;
        if (this.state.status === "PAUSED") return;
        this.update({ status: "RUNNING" });
        this.schedule(this.state.config.intervalSeconds * 1000, id);
      } catch (error) {
        if (id === this.runId) this.stop(error?.message || "Automation stopped because of an unexpected error.");
      } finally {
        if (id === this.runId) this.busy = false;
      }
    }
  }
  window.AIAutoSenderEngine = AutomationEngine;
})();
