(() => {
  if (window.__AI_AUTO_SENDER_READY__) return;
  const adapters = Object.values(window.AIAutoSenderAdapters);
  const adapter = adapters.map(item => new item.Adapter()).find(item => item.matches(location.href));
  if (!adapter) return;
  window.__AI_AUTO_SENDER_READY__ = true;

  let engine;
  const report = state => {
    chrome.runtime.sendMessage({ type: "STATE_UPDATE", state }).catch(() => {});
  };
  engine = new window.AIAutoSenderEngine(adapter, report);
  const ready = chrome.runtime.sendMessage({ type: "GET_OWN_STATE" }).then(result => {
    const saved = result?.state;
    if (!saved) return;
    engine.state = {
      ...engine.state,
      ...saved,
      status: ["RUNNING", "PAUSED", "WAITING_FOR_RESPONSE"].includes(saved.status) ? "STOPPED" : saved.status,
      nextAt: null,
      error: ["RUNNING", "PAUSED", "WAITING_FOR_RESPONSE"].includes(saved.status)
        ? "The page was reloaded. Automation stopped."
        : (saved.error || "")
    };
    report(engine.snapshot());
  }).catch(() => {});

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type === "GET_STATUS") {
      ready.then(() => sendResponse({ ok: true, adapter: adapter.id, name: adapter.constructor.name.replace("Adapter", ""), state: engine.snapshot() }));
      return true;
    }
    if (message?.type === "START") {
      engine.start(message.config).then(state => sendResponse({ ok: true, state })).catch(error => sendResponse({ ok: false, error: error.message }));
      return true;
    }
    if (message?.type === "PAUSE") {
      sendResponse({ ok: true, state: engine.pause() });
      return;
    }
    if (message?.type === "RESUME") {
      sendResponse({ ok: true, state: engine.resume() });
      return;
    }
    if (message?.type === "STOP") {
      sendResponse({ ok: true, state: engine.stop() });
      return;
    }
  });
})();
