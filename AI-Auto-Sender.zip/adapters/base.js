(() => {
  const visible = (element) => {
    if (!element || !element.isConnected) return false;
    for (let current = element; current && current !== document.documentElement; current = current.parentElement) {
      const style = getComputedStyle(current);
      if (style.display === "none" || style.visibility === "hidden" || Number(style.opacity) === 0) return false;
      if (current.getAttribute("aria-hidden") === "true") return false;
    }
    const rect = element.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && element.getClientRects().length > 0;
  };

  class BaseAdapter {
    matches() { return false; }
    findComposer() { return null; }
    findSendButton() { return null; }
    isGenerating() { return false; }
    get visible() { return visible; }

    async insertMessage(message) {
      const composer = this.findComposer();
      if (!composer) throw new Error("Could not find the message box. Make sure an AI conversation is open.");
      composer.focus();
      const text = String(message);

      if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
        const proto = composer instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
        if (setter) setter.call(composer, text); else composer.value = text;
        composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
        composer.dispatchEvent(new Event("change", { bubbles: true }));
      } else {
        composer.focus();
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(composer);
        selection.removeAllRanges();
        selection.addRange(range);
        document.execCommand("delete");
        document.execCommand("insertText", false, text);
        composer.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      }
      await new Promise(resolve => setTimeout(resolve, 100));
      if (this.readComposerText(composer).trim() !== text.trim()) {
        throw new Error("The message could not be inserted into the composer.");
      }
      return composer;
    }

    readComposerText(composer) {
      return composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement
        ? composer.value
        : (composer.innerText || composer.textContent || "");
    }

    async sendMessage(canSend = () => true) {
      const composer = this.findComposer();
      if (!composer) throw new Error("Could not find the message box. Make sure an AI conversation is open.");
      const button = this.findSendButton();
      if (!button) throw new Error("Could not find the Send button.");
      if (button.disabled || button.getAttribute("aria-disabled") === "true") {
        throw new Error("The Send button is not available.");
      }
      if (!canSend()) return false;
      button.click();
      const startedAt = Date.now();
      while (Date.now() - startedAt < 5000) {
        if (!composer.isConnected) return true;
        if (this.readComposerText(composer).trim() === "") return true;
        if (this.isGenerating()) return true;
        await new Promise(resolve => setTimeout(resolve, 150));
      }
      throw new Error("The message was not submitted. Please check the conversation and try again.");
    }

    waitForDomChange(timeoutMs = 1000) {
      return new Promise(resolve => {
        let done = false;
        const finish = () => {
          if (done) return;
          done = true;
          observer.disconnect();
          clearTimeout(timer);
          resolve();
        };
        const observer = new MutationObserver(finish);
        observer.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
        const timer = setTimeout(finish, timeoutMs);
      });
    }

    async waitForResponseToFinish({ isCurrent = () => true, onWaiting = () => {} } = {}) {
      onWaiting("Waiting for response...");
      const startedAt = Date.now();
      let sawGeneration = this.isGenerating();
      let stableSince = 0;
      while (isCurrent()) {
        const generating = this.isGenerating();
        if (generating) {
          sawGeneration = true;
          stableSince = 0;
        } else if (sawGeneration) {
          if (!stableSince) stableSince = Date.now();
          if (Date.now() - stableSince >= 1200) return;
        } else if (Date.now() - startedAt >= 20000) {
          throw new Error("Could not detect the AI response. Automation stopped to avoid sending over an active response.");
        }
        if (Date.now() - startedAt > 10 * 60 * 1000) throw new Error("The AI response took too long. Automation stopped.");
        await this.waitForDomChange(700);
      }
    }
  }

  window.AIAutoSenderAdapters = window.AIAutoSenderAdapters || {};
  window.AIAutoSenderBaseAdapter = BaseAdapter;
})();
