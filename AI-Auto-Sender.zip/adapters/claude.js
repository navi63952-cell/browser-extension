(() => {
  const SELECTORS = {
    composer: [
      'div[contenteditable="true"][data-placeholder]',
      'div[contenteditable="true"].ProseMirror',
      'div[contenteditable="true"][role="textbox"]',
      "textarea[placeholder]"
    ],
    send: [
      'button[aria-label*="Send message" i]',
      'button[aria-label="Send" i]',
      'button[data-testid*="send" i]'
    ],
    generating: [
      'button[aria-label*="Stop response" i]',
      'button[aria-label*="Stop generating" i]',
      'button[data-testid*="stop" i]'
    ]
  };
  class ClaudeAdapter extends window.AIAutoSenderBaseAdapter {
    matches(url) { return new URL(url).hostname === "claude.ai"; }
    findComposer() {
      for (const selector of SELECTORS.composer) {
        const found = [...document.querySelectorAll(selector)].find(el => this.visible(el));
        if (found) return found;
      }
      return [...document.querySelectorAll('[contenteditable="true"], [role="textbox"]')].find(el => this.visible(el)) || null;
    }
    findSendButton() {
      for (const selector of SELECTORS.send) {
        const found = [...document.querySelectorAll(selector)].find(el => this.visible(el));
        if (found) return found;
      }
      const composer = this.findComposer();
      return composer?.closest("form")?.querySelector("button[type=submit]") || composer?.closest("form")?.querySelector("button") || null;
    }
    isGenerating() { return SELECTORS.generating.some(s => [...document.querySelectorAll(s)].some(el => this.visible(el))); }
  }
  window.AIAutoSenderAdapters.claude = { id: "claude", name: "Claude", Adapter: ClaudeAdapter };
})();
