(() => {
  const SELECTORS = {
    composer: [
      "#prompt-textarea",
      '[data-testid="prompt-textarea"]',
      'div[contenteditable="true"][data-placeholder]',
      "textarea[placeholder]"
    ],
    send: [
      'button[data-testid="send-button"]',
      'button[aria-label*="Send" i]',
      'button[aria-label*="send message" i]'
    ],
    generating: [
      'button[data-testid="stop-button"]',
      'button[aria-label*="Stop generating" i]',
      'button[aria-label*="Stop streaming" i]'
    ]
  };
  class ChatGPTAdapter extends window.AIAutoSenderBaseAdapter {
    matches(url) { return new URL(url).hostname === "chatgpt.com"; }
    findComposer() {
      for (const selector of SELECTORS.composer) {
        const found = [...document.querySelectorAll(selector)].find(el => this.visible(el) && !el.disabled);
        if (found) return found;
      }
      return [...document.querySelectorAll('[role="textbox"], [contenteditable="true"]')]
        .find(el => this.visible(el) && !el.closest('[aria-hidden="true"]')) || null;
    }
    findSendButton() {
      for (const selector of SELECTORS.send) {
        const found = [...document.querySelectorAll(selector)].find(el => this.visible(el));
        if (found) return found;
      }
      const composer = this.findComposer();
      return composer?.closest("form")?.querySelector('button[type="submit"]') || null;
    }
    isGenerating() {
      return SELECTORS.generating.some(selector =>
        [...document.querySelectorAll(selector)].some(el =>
          this.visible(el) && !el.disabled && el.getAttribute("aria-disabled") !== "true"
        )
      );
    }
  }
  window.AIAutoSenderAdapters.chatgpt = { id: "chatgpt", name: "ChatGPT", Adapter: ChatGPTAdapter };
})();
