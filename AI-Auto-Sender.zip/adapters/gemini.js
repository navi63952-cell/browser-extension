(() => {
  const SELECTORS = {
    composer: [
      'div[contenteditable="true"][role="textbox"]',
      'div[contenteditable="true"].ql-editor',
      'rich-textarea [contenteditable="true"]',
      'textarea[aria-label*="prompt" i]'
    ],
    send: [
      'button[aria-label*="Send" i]',
      'button[data-test-id*="send" i]',
      'button[mattooltip*="Send" i]',
      'button[title*="Send" i]',
      'button[data-tooltip*="send" i]',
      'button[type="submit"]',
      '[role="button"][aria-label*="send" i]',
      '[role="button"][data-tooltip*="send" i]',
      '[role="button"][title*="send" i]'
    ],
    generating: [
      'button[aria-label*="Stop generating" i]',
      'button[aria-label*="Stop response" i]',
      '[data-test-id*="stop" i]'
    ]
  };
  function queryAllDeep(selector, root = document) {
    const results = [...root.querySelectorAll(selector)];
    for (const element of root.querySelectorAll("*")) {
      if (element.shadowRoot) results.push(...queryAllDeep(selector, element.shadowRoot));
    }
    return [...new Set(results)];
  }
  function parentAcrossShadow(element) {
    if (element.parentElement) return element.parentElement;
    return element.getRootNode?.().host || null;
  }

  class GeminiAdapter extends window.AIAutoSenderBaseAdapter {
    matches(url) { return new URL(url).hostname === "gemini.google.com"; }
    findComposer() {
      for (const selector of SELECTORS.composer) {
        const found = queryAllDeep(selector).find(el => this.visible(el));
        if (found) return found;
      }
      return queryAllDeep('[role="textbox"]').find(el => this.visible(el)) || null;
    }
    async insertMessage(message) {
      const composer = this.findComposer();
      if (!composer) throw new Error("Could not find the message box. Make sure a Gemini conversation is open.");
      if (composer instanceof HTMLTextAreaElement || composer instanceof HTMLInputElement) {
        return super.insertMessage(message);
      }

      const text = String(message);
      const normalized = value => String(value)
        .replace(/\r\n?/g, "\n")
        .replace(/\u00a0/g, " ")
        .replace(/\n{2,}/g, "\n")
        .trim();
      const readText = () => composer.innerText || composer.textContent || "";
      const selectAll = () => {
        composer.focus();
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(composer);
        selection.removeAllRanges();
        selection.addRange(range);
      };

      selectAll();
      document.execCommand("delete");
      document.execCommand("insertText", false, text);
      await new Promise(resolve => setTimeout(resolve, 100));

      // Gemini's rich-text editor can reject execCommand without throwing.
      // If that happened, replace its editable contents and notify the app.
      if (normalized(readText()) !== normalized(text)) {
        composer.dispatchEvent(new InputEvent("beforeinput", {
          bubbles: true, cancelable: true, inputType: "insertText", data: text
        }));
        selectAll();
        const selection = window.getSelection();
        const range = selection.getRangeAt(0);
        range.deleteContents();
        range.insertNode(document.createTextNode(text));
        range.collapse(false);
        selection.removeAllRanges();
        selection.addRange(range);
        composer.dispatchEvent(new InputEvent("input", {
          bubbles: true, inputType: "insertText", data: text
        }));
        composer.dispatchEvent(new Event("change", { bubbles: true }));
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      if (normalized(readText()) !== normalized(text)) {
        throw new Error("Gemini did not accept the message in its prompt box. Click the prompt box and try again.");
      }
      return composer;
    }
    findSendButton() {
      for (const selector of SELECTORS.send) {
        const found = queryAllDeep(selector).find(el => this.visible(el));
        if (found) return found;
      }
      const composer = this.findComposer();
      for (let scope = composer, depth = 0; scope && depth < 7; scope = parentAcrossShadow(scope), depth += 1) {
        const buttons = queryAllDeep('button, [role="button"]', scope)
          .filter(button => this.visible(button) && !button.disabled && button.getAttribute("aria-disabled") !== "true");
        const sendButton = buttons.find(button => {
          const label = [button.getAttribute("aria-label"), button.getAttribute("title"),
            button.getAttribute("data-tooltip"), button.getAttribute("data-test-id"), button.innerText, button.textContent]
            .filter(Boolean).join(" ");
          return /send|submit/i.test(label);
        });
        if (sendButton) return sendButton;
        if (depth <= 2 && buttons.length === 1) return buttons[0];
      }
      return null;
    }
    async sendMessage(canSend = () => true) {
      if (this.findSendButton()) return super.sendMessage(canSend);
      const composer = this.findComposer();
      if (!composer) throw new Error("Could not find Gemini's message box.");
      if (!canSend()) return false;

      // Some Gemini layouts expose the blue send control only through a closed
      // component tree. Enter is the normal submit shortcut for its composer.
      composer.focus();
      composer.dispatchEvent(new KeyboardEvent("keydown", {
        key: "Enter", code: "Enter", keyCode: 13, which: 13,
        bubbles: true, cancelable: true
      }));
      composer.dispatchEvent(new KeyboardEvent("keyup", {
        key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true
      }));

      const startedAt = Date.now();
      while (Date.now() - startedAt < 5000) {
        if (!canSend()) return false;
        if (!composer.isConnected || this.readComposerText(composer).trim() === "" || this.isGenerating()) return true;
        await new Promise(resolve => setTimeout(resolve, 150));
      }
      throw new Error("Gemini's Send control was not accessible. Press the blue Send arrow manually, then try again.");
    }
    isGenerating() { return SELECTORS.generating.some(s => queryAllDeep(s).some(el => this.visible(el))); }
  }
  window.AIAutoSenderAdapters.gemini = { id: "gemini", name: "Gemini", Adapter: GeminiAdapter };
})();
