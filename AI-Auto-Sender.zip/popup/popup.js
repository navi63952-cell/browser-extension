const $ = id => document.getElementById(id);
const ui = {
  website: $("website"), detected: $("detected"), siteIcon: $("siteIcon"),
  connection: $("connection"), siteHint: $("siteHint"), message: $("message"),
  interval: $("interval"), sendImmediately: $("sendImmediately"),
  waitForResponse: $("waitForResponse"), start: $("start"), pause: $("pause"),
  resume: $("resume"), stop: $("stop"), status: $("status"), count: $("count"),
  next: $("next"), error: $("error"), dot: $("statusDot")
};
const DEFAULTS = {
  message: "", intervalSeconds: 30, selectedAI: "auto",
  sendImmediately: true, waitForResponse: true
};
const AI_SITES = {
  "chatgpt.com": { id: "chatgpt", name: "ChatGPT", icon: "✳" },
  "gemini.google.com": { id: "gemini", name: "Gemini", icon: "✦" },
  "claude.ai": { id: "claude", name: "Claude", icon: "✺" }
};
let tabId = null;
let tabUrl = "";
let detectedSite = null;
let latestState = null;
let refreshHandle = null;
let unsupportedMessage = "";
let transientError = "";

function matchSite(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") return null;
    return AI_SITES[parsed.hostname] || null;
  } catch {
    return null;
  }
}
function unsupportedReason(url) {
  if (!url) return "Can't read this tab. Open ChatGPT, Gemini, or Claude in a regular browser tab.";
  if (url.startsWith("chrome://") || url.startsWith("chrome-extension://") || url.startsWith("edge://")) {
    return "Chrome protects this page. Open ChatGPT, Gemini, or Claude in this tab.";
  }
  if (url.startsWith("file:")) {
    return "Local files aren't supported. Open ChatGPT, Gemini, or Claude in this tab.";
  }
  return "Open ChatGPT, Gemini, or Claude in this tab to use AI Auto Sender.";
}
async function sendCommand(command) {
  if (tabId == null) return { ok: false, error: unsupportedMessage || "No active tab is available." };
  try {
    return await chrome.runtime.sendMessage({ type: "TAB_COMMAND", tabId, command });
  } catch {
    return { ok: false, error: "Chrome could not reach the extension service worker. Reload the extension and try again." };
  }
}
function setSite(site, errorText = "", connected = false) {
  detectedSite = site;
  ui.website.value = site?.id || "auto";
  ui.website.disabled = !site || ["RUNNING", "WAITING_FOR_RESPONSE"].includes(latestState?.status);
  ui.detected.textContent = site ? "Detected: " + site.name : "No supported AI tab";
  ui.siteIcon.textContent = site?.icon || "↗";
  ui.connection.className = "connection-dot " + (connected ? "connected" : site ? "disconnected" : "unsupported");
  ui.connection.title = connected
    ? "Connected to this AI tab"
    : site ? "AI site detected, but the page connection is unavailable" : "Unsupported tab";
  ui.siteHint.textContent = site
    ? "Matched automatically from this tab."
    : "Open a supported AI chat to enable sending.";
  unsupportedMessage = errorText;
}
function render(state = latestState) {
  const status = state?.status || "STOPPED";
  const names = {
    STOPPED: "Stopped",
    RUNNING: "Running",
    PAUSED: "Paused",
    WAITING_FOR_RESPONSE: "Waiting for response...",
    ERROR: "Error"
  };
  ui.status.textContent = names[status] || status;
  ui.count.textContent = (state?.messagesSent || 0) + " sent";
  ui.dot.className = "status-dot " +
    (status === "RUNNING" ? "running" : status === "WAITING_FOR_RESPONSE" ? "waiting" : "");
  const seconds = state?.nextAt ? Math.max(0, Math.ceil((state.nextAt - Date.now()) / 1000)) : null;
  if (status === "WAITING_FOR_RESPONSE") {
    const interval = state?.config?.intervalSeconds || 30;
    ui.next.textContent = "The " + interval + "s interval starts after the reply finishes.";
  } else {
    ui.next.textContent = status === "RUNNING" && seconds !== null ? "Next message in " + seconds + "s" : "";
  }
  ui.error.textContent = state?.error || transientError || unsupportedMessage || "";

  const active = status === "RUNNING" || status === "WAITING_FOR_RESPONSE";
  const canUseSite = Boolean(detectedSite && tabId != null);
  ui.start.disabled = !canUseSite || active;
  ui.pause.disabled = !canUseSite || (status !== "RUNNING" && status !== "WAITING_FOR_RESPONSE");
  ui.resume.disabled = !canUseSite || status !== "PAUSED";
  ui.stop.disabled = !canUseSite || (status === "STOPPED" && !state?.error);
  ui.website.disabled = !canUseSite || active;
}
async function refresh() {
  if (tabId == null || !detectedSite) return;
  try {
    const result = await chrome.runtime.sendMessage({ type: "GET_TAB_STATE", tabId });
    if (result?.ok && result.state) latestState = result.state;
    render();
  } catch {
    transientError = "Couldn't refresh automation status. Reload the extension if this continues.";
    render();
  }
}
async function saveSettings() {
  const settings = {
    message: ui.message.value,
    intervalSeconds: Math.max(1, Math.min(86400, Number(ui.interval.value) || 30)),
    selectedAI: detectedSite?.id || "auto",
    sendImmediately: ui.sendImmediately.checked,
    waitForResponse: ui.waitForResponse.checked
  };
  await chrome.storage.local.set({ settings });
  return settings;
}

async function init() {
  let tabs = [];
  let stored = {};
  try {
    const results = await Promise.allSettled([
      chrome.tabs.query({ active: true, currentWindow: true }),
      chrome.storage.local.get("settings")
    ]);
    if (results[0].status === "fulfilled") tabs = results[0].value || [];
    if (results[1].status === "fulfilled") stored = results[1].value || {};
    const activeTab = tabs[0];
    tabId = Number.isInteger(activeTab?.id) ? activeTab.id : null;
    tabUrl = typeof activeTab?.url === "string" ? activeTab.url : "";
    const site = matchSite(tabUrl);
    setSite(site, site ? "" : unsupportedReason(tabUrl));

    const settings = { ...DEFAULTS, ...(stored.settings || {}) };
    ui.message.value = settings.message;
    ui.interval.value = settings.intervalSeconds;
    ui.sendImmediately.checked = settings.sendImmediately;
    ui.waitForResponse.checked = settings.waitForResponse;

    if (site && tabId != null) {
      const result = await sendCommand({ type: "GET_STATUS" });
      if (result?.ok) {
        latestState = result.state;
        setSite(site, "", true);
        transientError = "";
      } else {
        setSite(site, "", false);
        const saved = await chrome.runtime.sendMessage({ type: "GET_TAB_STATE", tabId }).catch(() => null);
        latestState = saved?.state || null;
        transientError = result?.error || "Reload this AI tab so the extension can connect.";
      }
    }
    render();
    refreshHandle = setInterval(refresh, 1000);
  } catch {
    tabId = null;
    setSite(null, "Can't access this tab. Open ChatGPT, Gemini, or Claude in a regular browser tab.");
    render();
  }
}

ui.website.addEventListener("change", () => {
  // The active tab URL is authoritative. Keep the dropdown aligned with its adapter.
  ui.website.value = detectedSite?.id || "auto";
  transientError = "";
  render();
});

ui.start.addEventListener("click", async () => {
  if (!detectedSite) {
    transientError = unsupportedMessage || "Open ChatGPT, Gemini, or Claude in this tab.";
    render();
    return;
  }
  if (!ui.message.value.trim()) {
    transientError = "Enter a message to send.";
    render();
    return;
  }
  transientError = "";
  ui.start.disabled = true;
  try {
    const config = await saveSettings();
    const result = await sendCommand({ type: "START", config });
    if (!result?.ok) transientError = result?.error || "Could not start automation.";
    else { latestState = result.state; transientError = ""; }
  } catch {
    transientError = "Could not start automation. Check the active AI tab and try again.";
  }
  render();
});
ui.pause.addEventListener("click", async () => {
  const result = await sendCommand({ type: "PAUSE" });
  if (!result?.ok) transientError = result?.error || "Could not pause automation.";
  else { latestState = result.state; transientError = ""; }
  render();
});
ui.resume.addEventListener("click", async () => {
  const result = await sendCommand({ type: "RESUME" });
  if (!result?.ok) transientError = result?.error || "Could not resume automation.";
  else { latestState = result.state; transientError = ""; }
  render();
});
ui.stop.addEventListener("click", async () => {
  const result = await sendCommand({ type: "STOP" });
  if (!result?.ok) transientError = result?.error || "Could not stop automation.";
  else { latestState = result.state; transientError = ""; }
  render();
});
window.addEventListener("unload", () => clearInterval(refreshHandle));
init();
