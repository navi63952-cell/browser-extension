const STORAGE_KEY = "tabStates";
const CONTENT_SCRIPTS = [
  "adapters/base.js",
  "adapters/chatgpt.js",
  "adapters/gemini.js",
  "adapters/claude.js",
  "content/automation-engine.js",
  "content/content.js"
];

async function readStates() {
  return (await chrome.storage.local.get(STORAGE_KEY))[STORAGE_KEY] || {};
}
async function saveState(tabId, state) {
  const states = await readStates();
  states[tabId] = { ...states[tabId], ...state, updatedAt: Date.now() };
  await chrome.storage.local.set({ [STORAGE_KEY]: states });
  return states[tabId];
}

async function connectToTab(tabId, command) {
  try {
    return await chrome.tabs.sendMessage(tabId, command);
  } catch {
    // Static content scripts do not enter tabs that were already open when the
    // extension was installed or reloaded. Inject the same modular bundle once.
    try {
      const check = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => Boolean(window.__AI_AUTO_SENDER_READY__)
      });
      if (!check?.[0]?.result) {
        await chrome.scripting.executeScript({ target: { tabId }, files: CONTENT_SCRIPTS });
      }
      return await chrome.tabs.sendMessage(tabId, command);
    } catch {
      return {
        ok: false,
        error: "Could not connect to this AI tab. Reload the tab or allow AI Auto Sender access to this site."
      };
    }
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "STATE_UPDATE" && sender.tab?.id != null) {
    saveState(sender.tab.id, message.state).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "GET_TAB_STATE") {
    readStates().then(states => sendResponse({ ok: true, state: states[message.tabId] || null }));
    return true;
  }
  if (message?.type === "GET_OWN_STATE" && sender.tab?.id != null) {
    readStates().then(states => sendResponse({ ok: true, state: states[sender.tab.id] || null }));
    return true;
  }
  if (message?.type === "TAB_COMMAND") {
    (async () => {
      const tabId = Number(message.tabId);
      let tab;
      try { tab = await chrome.tabs.get(tabId); }
      catch { sendResponse({ ok: false, error: "The selected tab is no longer open." }); return; }
      if (!/^https:\/\/(chatgpt\.com|gemini\.google\.com|claude\.ai)(\/|$)/i.test(tab.url || "")) {
        sendResponse({ ok: false, error: "This AI website isn't supported yet." }); return;
      }
      try {
        const result = await connectToTab(tabId, message.command);
        if (result?.state) await saveState(tabId, result.state);
        sendResponse(result || { ok: false, error: "The extension could not reach this page. Reload the AI tab and try again." });
      } catch {
        sendResponse({ ok: false, error: "The extension could not reach this page. Reload the AI tab and try again." });
      }
    })();
    return true;
  }
});

chrome.tabs.onRemoved.addListener(async tabId => {
  const states = await readStates();
  delete states[tabId];
  await chrome.storage.local.set({ [STORAGE_KEY]: states });
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const states = await readStates();
  const previous = states[tabId];
  let changedWebsite = false;
  try {
    const previousHost = new URL(previous?.tabUrl || "").hostname;
    const nextHost = new URL(changeInfo.url).hostname;
    changedWebsite = previousHost !== nextHost;
  } catch { changedWebsite = true; }
  if (!changedWebsite) return;
  if (previous && ["RUNNING", "PAUSED", "WAITING_FOR_RESPONSE"].includes(previous.status)) {
    states[tabId] = { ...previous, status: "STOPPED", nextAt: null, error: "AI website changed. Automation stopped.", updatedAt: Date.now() };
    await chrome.storage.local.set({ [STORAGE_KEY]: states });
  }
});
